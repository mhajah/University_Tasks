﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;

namespace Zad1
{

    [MemoryDiagnoser]
    public class Test
    {


        [Benchmark]
        [Arguments(1, 2)]
        public int DoWork1(int x, int y)
        {
            return x + y;
        }

        [Benchmark]
        [Arguments(3, 4)]
        public dynamic DoWork2(int x, int y)
        {
            return x + y;
        }
    }
    public class Program
    {
        public static void Main(string[] args)
        {

            var summary = BenchmarkRunner.Run<Test>();
            Test wynik = new Test();
            wynik.DoWork1(2, 3);
            wynik.DoWork2(2, 3);


        }

    }

}