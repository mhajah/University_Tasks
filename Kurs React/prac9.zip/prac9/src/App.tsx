
import './App.css'

function App() {

  return (
    <div className="text-3xl font-bold underline">
      test
    </div>
  )
}

export default App
