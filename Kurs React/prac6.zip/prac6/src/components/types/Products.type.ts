export interface IProducts {
    id: number;
    name: string;
    type: string;
    price: number;
    avail: boolean;
    noitems: number;
}