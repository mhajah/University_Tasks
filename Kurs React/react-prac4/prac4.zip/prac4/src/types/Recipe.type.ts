export interface IRecipe {
    id: number;
    title: string;
    content: string;
    isFav: boolean;
}