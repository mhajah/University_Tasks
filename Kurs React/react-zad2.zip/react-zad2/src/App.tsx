

import ToDoContainer from "./components/toDoContainer";

import './App.css'

function App() {
//https://uizard.io/static/8fada368b591ba3b3c70e72408cb6dee/a8e47/2b300cc852aafa482f574d13f7a80ec60666f9d9-1440x835.png
  return (
    <div className="App">
      <ToDoContainer />
    </div>
  )
}

export default App
