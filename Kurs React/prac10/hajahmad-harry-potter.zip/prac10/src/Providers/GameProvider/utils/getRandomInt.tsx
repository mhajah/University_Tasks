export default function getRandomInt(max: number) {
    return Math.floor(Math.random() * max);
}