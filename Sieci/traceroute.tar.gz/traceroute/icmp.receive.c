#include "main.h"

bool icmp_reply_verify(struct icmp *icmp_packet, int i) {
    return icmp_packet->icmp_type == ICMP_ECHOREPLY && icmp_packet->icmp_id == getpid() && icmp_packet->icmp_seq / 3 == i;
}

bool icmp_time_exceeded_verify(struct icmp *icmp_packet, int i) {
    if (icmp_packet->icmp_type == ICMP_TIME_EXCEEDED) {
        struct ip *inner_ip = (struct ip *)&icmp_packet->icmp_data;
        struct icmp *inner_icmp = (struct icmp *)((u_int8_t *)inner_ip + 4 * inner_ip->ip_hl);
        return inner_icmp->icmp_id == getpid() && inner_icmp->icmp_seq / 3 == i;
    }
    return false;
}

in_addr_t icmp_receive(int socket_descriptor, int id) {
    struct sockaddr_in sender;
    u_int8_t buffer[IP_MAXPACKET];
    socklen_t sender_len = sizeof(sender);

    /*
    * recvfrom Return Value
    * These calls return the number of bytes received, or -1 if an error occurred. 
    * The return value will be 0 when the peer has performed an orderly shutdown. 
    */

    int is_received = recvfrom(socket_descriptor, &buffer, IP_MAXPACKET, 0, (struct sockaddr *)&sender, &sender_len);
    if (is_received == -1) {
        fprintf(stderr, "Odbior danych zakonczyl sie bledem: %s\n", strerror(errno));
        exit(-1);
    }

    struct ip *ip_header = (struct ip *)&buffer;
    struct icmp *icmp_header = (struct icmp *)((u_int8_t *)ip_header + 4 * ip_header->ip_hl);
    
    
    return sender.sin_addr.s_addr;

}


// int main()
// {
// 	int sock_fd = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
// 	if (sock_fd < 0) {
// 		fprintf(stderr, "socket error: %s\n", strerror(errno)); 
// 		return EXIT_FAILURE;
// 	}

// 	for (;;) {
// 		struct sockaddr_in sender;
// 		socklen_t sender_len = sizeof(sender);
// 		u_int8_t buffer[IP_MAXPACKET];

// 		ssize_t packet_len = recvfrom (sock_fd, buffer, IP_MAXPACKET, 0, (struct sockaddr*)&sender, &sender_len);
// 		if (packet_len < 0) {
// 			fprintf(stderr, "recvfrom error: %s\n", strerror(errno));
// 			return EXIT_FAILURE;
// 		}

// 		char sender_ip_str[20]; 
// 		inet_ntop(AF_INET, &(sender.sin_addr), sender_ip_str, sizeof(sender_ip_str));
// 		printf ("Received IP packet with ICMP content from: %s\n", sender_ip_str);

// 		struct ip* ip_header = (struct ip*) buffer;
// 		ssize_t	ip_header_len = 4 * (ssize_t)(ip_header->ip_hl);

// 		printf("IP header: ");
// 		print_as_bytes(buffer, ip_header_len);
// 		printf("\n");

// 		printf("IP data:   ");
// 		print_as_bytes(buffer + ip_header_len, packet_len - ip_header_len);
// 		printf("\n\n");
// 	}
// }
