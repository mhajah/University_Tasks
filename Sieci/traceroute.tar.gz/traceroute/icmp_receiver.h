#include "main.h"

bool icmp_reply_verify(struct icmp *icmp_packet, int i);
bool icmp_time_exceeded_verify(struct icmp *icmp_packet, int i);
in_addr_t icmp_receive(int socket_descriptor, int id);