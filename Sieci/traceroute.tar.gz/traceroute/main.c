#include "main.h"
#include "icmp_sender.h"
#include "icmp_receiver.h"
#include <sys/select.h>


struct sockaddr_in addr_ip;
int socket_descriptor;
struct timespec t, st;
struct in_addr destination_ips[3];
int destination_milliseconds[3];
int destination_replies;


int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Nieprawidlowa liczba argumentow (oczekiwany 1)\n");
        return -1; 
    }

    addr_ip.sin_family = AF_INET;
    addr_ip.sin_addr.s_addr = inet_addr(argv[1]);

    if (addr_ip.sin_addr.s_addr == (in_addr_t)-1) {
        fprintf(stderr, "Nieprawidlowy format adresu IP\n");
    }

    socket_descriptor = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
    if (socket_descriptor == -1) fprintf(stderr, "Nie udalo sie utworzyc gniazda\n");

    for (int i=1; i <= 30; i++) {
        clock_gettime(CLOCK_MONOTONIC, &t);
        for (int j=1; j <= 3; j++) {
            icmp_send(socket_descriptor, addr_ip, i, j);
        }
        struct timeval timeout;
        timeout.tv_sec = 1;
        timeout.tv_usec = 0;
        destination_replies = 0;

        while (destination_replies < 3) {
            fd_set set;
            FD_ZERO(&set);
            FD_SET(socket_descriptor, &set);
            int result = select(socket_descriptor+1, &set, NULL, NULL, &timeout);
            printf("result: %d \n", result);
            if (result == -1) {
                fprintf(stderr, "Nie udało się czekać na wynik!\n");
            }
            if (result > 0) {
                in_addr_t destination_ip = icmp_receive(socket_descriptor, i);
                printf("receive: %d\n", destination_ip);

                if (destination_ip != (in_addr_t)-1) {

                    destination_ips[destination_replies].s_addr = destination_ip;
                    
                    clock_gettime(CLOCK_MONOTONIC, &st);
                    destination_milliseconds[destination_replies] = (st.tv_sec - t.tv_sec)*1000 + (st.tv_nsec - t.tv_nsec)/1000000;
                    destination_replies++;
                }
            }
            if (result == 0) break;
        }

        printf("%d.", i);
        if (destination_replies == 0) {
            printf("* \n");
            continue;
        }

        printf("%s ", inet_ntoa(destination_ips[0]));

        if (destination_replies >= 2 && destination_ips[0].s_addr != destination_ips[1].s_addr) {
            printf("%s ", inet_ntoa(destination_ips[1]));
        }

        if (destination_replies >= 3 && destination_ips[0].s_addr != destination_ips[2].s_addr && destination_ips[1].s_addr != destination_ips[2].s_addr) {
            printf("%s ", inet_ntoa(destination_ips[2]));
        }

        if (destination_replies == 3) {
            int average = (destination_milliseconds[0] + destination_milliseconds[1] + destination_milliseconds[2])/3;
            printf("%d ms\n", average);
        } else {
            printf("???\n");
        }

        if (destination_ips[0].s_addr == addr_ip.sin_addr.s_addr) break;
    }

    return 0;
}