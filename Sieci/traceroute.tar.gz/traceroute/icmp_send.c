
#include "icmp_sender.h"
#include "main.h"

/*
* Funkcja wysyłająca pakiet.
* socket_descriptor: deskryptor gniazda
* addr_ip: adres, do którego wysyłamy
* ttl: time to live
* seq: numer sekwencyjny pakietu
*/

void icmp_send(int socket_descriptor, struct sockaddr_in addr_ip, int ttl, int seq) {
    struct icmp data_packet;
    data_packet.icmp_type = ICMP_ECHO;
    data_packet.icmp_id = getpid();
    data_packet.icmp_code = 0;
    data_packet.icmp_seq = seq;
    data_packet.icmp_cksum = compute_icmp_checksum((u_int16_t *)&data_packet, sizeof(struct icmp));

    /* 
    * Do manipulacji opcjami gniazda o podanym deskryptorze uzywa sie setsockopt(),
    * ktora zwraca 0 w przypadku sukcesu i -1 w przypadku bledu
    */
    
    int is_socketset_ok = setsockopt(socket_descriptor, IPPROTO_IP, IP_TTL, &ttl, sizeof(int));

    if (is_socketset_ok == -1) {
        fprintf(stderr, "Wystapil blad podczas konfiguracji gniazda %s ...\n", strerror(errno));
        exit(-1);
    }

    /*
    * sendto() transmituje wiadomosc do innego socketu.
    * Zwraca liczbe wyslanych znakow w przypadku powodzenia i -1 w przypadku bledu
    */

    int is_sent_ok = sendto(socket_descriptor, &data_packet, sizeof(struct icmp), 0, (struct sockaddr *)&addr_ip, sizeof(struct sockaddr_in));

    if (is_sent_ok == -1) {
        fprintf(stderr, "!Wystapil blad podczas konfiguracji gniazda: %s ...\n", strerror(errno));
        exit(-1);
    }
}